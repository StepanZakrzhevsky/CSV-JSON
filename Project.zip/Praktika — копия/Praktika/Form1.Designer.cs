﻿
namespace Praktika
{
    partial class mainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rdb_csv = new System.Windows.Forms.RadioButton();
            this.rdb_json = new System.Windows.Forms.RadioButton();
            this.grpb_file_types = new System.Windows.Forms.GroupBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.ZGControl = new ZedGraph.ZedGraphControl();
            this.ComboBoxDevices = new System.Windows.Forms.ComboBox();
            this.ComboBoxSensors = new System.Windows.Forms.ComboBox();
            this.LabelDevices = new System.Windows.Forms.Label();
            this.LabelSensors = new System.Windows.Forms.Label();
            this.DatePickerBegin = new System.Windows.Forms.DateTimePicker();
            this.DatePickerEnd = new System.Windows.Forms.DateTimePicker();
            this.LabelBeginDate = new System.Windows.Forms.Label();
            this.LabelEndDate = new System.Windows.Forms.Label();
            this.ComboBoxBeginTime = new System.Windows.Forms.ComboBox();
            this.ComboBoxEndTime = new System.Windows.Forms.ComboBox();
            this.LabelBeginTime = new System.Windows.Forms.Label();
            this.LabelEndTime = new System.Windows.Forms.Label();
            this.gp_rdb = new System.Windows.Forms.GroupBox();
            this.rdb_min_max = new System.Windows.Forms.RadioButton();
            this.rdb_day = new System.Windows.Forms.RadioButton();
            this.rdb_three_hour = new System.Windows.Forms.RadioButton();
            this.rdb_hour = new System.Windows.Forms.RadioButton();
            this.rdb_real = new System.Windows.Forms.RadioButton();
            this.btn_build = new System.Windows.Forms.Button();
            this.gp_types = new System.Windows.Forms.GroupBox();
            this.rdb_curve = new System.Windows.Forms.RadioButton();
            this.rdb_column = new System.Windows.Forms.RadioButton();
            this.rdb_candle = new System.Windows.Forms.RadioButton();
            this.menuStrip1.SuspendLayout();
            this.grpb_file_types.SuspendLayout();
            this.gp_rdb.SuspendLayout();
            this.gp_types.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1326, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // rdb_csv
            // 
            this.rdb_csv.AutoSize = true;
            this.rdb_csv.Checked = true;
            this.rdb_csv.Location = new System.Drawing.Point(6, 21);
            this.rdb_csv.Name = "rdb_csv";
            this.rdb_csv.Size = new System.Drawing.Size(46, 17);
            this.rdb_csv.TabIndex = 7;
            this.rdb_csv.TabStop = true;
            this.rdb_csv.Text = "CSV";
            this.rdb_csv.UseVisualStyleBackColor = true;
            // 
            // rdb_json
            // 
            this.rdb_json.AutoSize = true;
            this.rdb_json.Location = new System.Drawing.Point(6, 44);
            this.rdb_json.Name = "rdb_json";
            this.rdb_json.Size = new System.Drawing.Size(53, 17);
            this.rdb_json.TabIndex = 8;
            this.rdb_json.Text = "JSON";
            this.rdb_json.UseVisualStyleBackColor = true;
            // 
            // grpb_file_types
            // 
            this.grpb_file_types.Controls.Add(this.rdb_csv);
            this.grpb_file_types.Controls.Add(this.rdb_json);
            this.grpb_file_types.Location = new System.Drawing.Point(16, 57);
            this.grpb_file_types.Name = "grpb_file_types";
            this.grpb_file_types.Size = new System.Drawing.Size(127, 65);
            this.grpb_file_types.TabIndex = 9;
            this.grpb_file_types.TabStop = false;
            this.grpb_file_types.Text = "Выберите тип файла";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(1144, 647);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(26, 18);
            this.richTextBox1.TabIndex = 11;
            this.richTextBox1.Text = "";
            this.richTextBox1.Visible = false;
            // 
            // ZGControl
            // 
            this.ZGControl.Location = new System.Drawing.Point(392, 57);
            this.ZGControl.Name = "ZGControl";
            this.ZGControl.ScrollGrace = 0D;
            this.ZGControl.ScrollMaxX = 0D;
            this.ZGControl.ScrollMaxY = 0D;
            this.ZGControl.ScrollMaxY2 = 0D;
            this.ZGControl.ScrollMinX = 0D;
            this.ZGControl.ScrollMinY = 0D;
            this.ZGControl.ScrollMinY2 = 0D;
            this.ZGControl.Size = new System.Drawing.Size(505, 309);
            this.ZGControl.TabIndex = 12;
            this.ZGControl.UseExtendedPrintDialog = true;
            // 
            // ComboBoxDevices
            // 
            this.ComboBoxDevices.Enabled = false;
            this.ComboBoxDevices.FormattingEnabled = true;
            this.ComboBoxDevices.Location = new System.Drawing.Point(16, 142);
            this.ComboBoxDevices.Name = "ComboBoxDevices";
            this.ComboBoxDevices.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxDevices.TabIndex = 13;
            this.ComboBoxDevices.SelectedIndexChanged += new System.EventHandler(this.ComboBoxDevices_SelectedIndexChanged);
            // 
            // ComboBoxSensors
            // 
            this.ComboBoxSensors.Enabled = false;
            this.ComboBoxSensors.FormattingEnabled = true;
            this.ComboBoxSensors.Location = new System.Drawing.Point(16, 190);
            this.ComboBoxSensors.Name = "ComboBoxSensors";
            this.ComboBoxSensors.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxSensors.TabIndex = 14;
            this.ComboBoxSensors.SelectedIndexChanged += new System.EventHandler(this.ComboBoxSensors_SelectedIndexChanged);
            // 
            // LabelDevices
            // 
            this.LabelDevices.AutoSize = true;
            this.LabelDevices.Location = new System.Drawing.Point(13, 125);
            this.LabelDevices.Name = "LabelDevices";
            this.LabelDevices.Size = new System.Drawing.Size(99, 13);
            this.LabelDevices.TabIndex = 15;
            this.LabelDevices.Text = "Выберите прибор:";
            // 
            // LabelSensors
            // 
            this.LabelSensors.AutoSize = true;
            this.LabelSensors.Location = new System.Drawing.Point(13, 168);
            this.LabelSensors.Name = "LabelSensors";
            this.LabelSensors.Size = new System.Drawing.Size(97, 13);
            this.LabelSensors.TabIndex = 16;
            this.LabelSensors.Text = "Выберите датчик:";
            // 
            // DatePickerBegin
            // 
            this.DatePickerBegin.Enabled = false;
            this.DatePickerBegin.Location = new System.Drawing.Point(16, 233);
            this.DatePickerBegin.Name = "DatePickerBegin";
            this.DatePickerBegin.Size = new System.Drawing.Size(215, 20);
            this.DatePickerBegin.TabIndex = 17;
            this.DatePickerBegin.ValueChanged += new System.EventHandler(this.DatePickerBegin_ValueChanged);
            // 
            // DatePickerEnd
            // 
            this.DatePickerEnd.Enabled = false;
            this.DatePickerEnd.Location = new System.Drawing.Point(16, 272);
            this.DatePickerEnd.Name = "DatePickerEnd";
            this.DatePickerEnd.Size = new System.Drawing.Size(215, 20);
            this.DatePickerEnd.TabIndex = 18;
            this.DatePickerEnd.ValueChanged += new System.EventHandler(this.DatePickerEnd_ValueChanged);
            // 
            // LabelBeginDate
            // 
            this.LabelBeginDate.AutoSize = true;
            this.LabelBeginDate.Location = new System.Drawing.Point(13, 214);
            this.LabelBeginDate.Name = "LabelBeginDate";
            this.LabelBeginDate.Size = new System.Drawing.Size(218, 13);
            this.LabelBeginDate.TabIndex = 19;
            this.LabelBeginDate.Text = "Выберите начало временного интервала:";
            // 
            // LabelEndDate
            // 
            this.LabelEndDate.AutoSize = true;
            this.LabelEndDate.Location = new System.Drawing.Point(13, 256);
            this.LabelEndDate.Name = "LabelEndDate";
            this.LabelEndDate.Size = new System.Drawing.Size(213, 13);
            this.LabelEndDate.TabIndex = 20;
            this.LabelEndDate.Text = "Выберите конец временного интервала:";
            // 
            // ComboBoxBeginTime
            // 
            this.ComboBoxBeginTime.Enabled = false;
            this.ComboBoxBeginTime.FormattingEnabled = true;
            this.ComboBoxBeginTime.Location = new System.Drawing.Point(1140, 686);
            this.ComboBoxBeginTime.Name = "ComboBoxBeginTime";
            this.ComboBoxBeginTime.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxBeginTime.TabIndex = 21;
            this.ComboBoxBeginTime.Visible = false;
            // 
            // ComboBoxEndTime
            // 
            this.ComboBoxEndTime.Enabled = false;
            this.ComboBoxEndTime.FormattingEnabled = true;
            this.ComboBoxEndTime.Location = new System.Drawing.Point(1140, 739);
            this.ComboBoxEndTime.Name = "ComboBoxEndTime";
            this.ComboBoxEndTime.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxEndTime.TabIndex = 22;
            this.ComboBoxEndTime.Visible = false;
            // 
            // LabelBeginTime
            // 
            this.LabelBeginTime.AutoSize = true;
            this.LabelBeginTime.Location = new System.Drawing.Point(1140, 668);
            this.LabelBeginTime.Name = "LabelBeginTime";
            this.LabelBeginTime.Size = new System.Drawing.Size(146, 13);
            this.LabelBeginTime.TabIndex = 23;
            this.LabelBeginTime.Text = "Choose begin of time interval:";
            this.LabelBeginTime.Visible = false;
            // 
            // LabelEndTime
            // 
            this.LabelEndTime.AutoSize = true;
            this.LabelEndTime.Location = new System.Drawing.Point(1140, 724);
            this.LabelEndTime.Name = "LabelEndTime";
            this.LabelEndTime.Size = new System.Drawing.Size(138, 13);
            this.LabelEndTime.TabIndex = 24;
            this.LabelEndTime.Text = "Choose end of time interval:";
            this.LabelEndTime.Visible = false;
            // 
            // gp_rdb
            // 
            this.gp_rdb.Controls.Add(this.rdb_min_max);
            this.gp_rdb.Controls.Add(this.rdb_day);
            this.gp_rdb.Controls.Add(this.rdb_three_hour);
            this.gp_rdb.Controls.Add(this.rdb_hour);
            this.gp_rdb.Controls.Add(this.rdb_real);
            this.gp_rdb.Enabled = false;
            this.gp_rdb.Location = new System.Drawing.Point(16, 298);
            this.gp_rdb.Name = "gp_rdb";
            this.gp_rdb.Size = new System.Drawing.Size(200, 100);
            this.gp_rdb.TabIndex = 25;
            this.gp_rdb.TabStop = false;
            this.gp_rdb.Text = "Выберите способ осреднения:";
            // 
            // rdb_min_max
            // 
            this.rdb_min_max.AutoSize = true;
            this.rdb_min_max.Location = new System.Drawing.Point(6, 65);
            this.rdb_min_max.Name = "rdb_min_max";
            this.rdb_min_max.Size = new System.Drawing.Size(177, 17);
            this.rdb_min_max.TabIndex = 4;
            this.rdb_min_max.TabStop = true;
            this.rdb_min_max.Text = "Максимум/минимум за сутки";
            this.rdb_min_max.UseVisualStyleBackColor = true;
            // 
            // rdb_day
            // 
            this.rdb_day.AutoSize = true;
            this.rdb_day.Location = new System.Drawing.Point(97, 42);
            this.rdb_day.Name = "rdb_day";
            this.rdb_day.Size = new System.Drawing.Size(69, 17);
            this.rdb_day.TabIndex = 3;
            this.rdb_day.TabStop = true;
            this.rdb_day.Text = "За сутки";
            this.rdb_day.UseVisualStyleBackColor = true;
            // 
            // rdb_three_hour
            // 
            this.rdb_three_hour.AutoSize = true;
            this.rdb_three_hour.Location = new System.Drawing.Point(6, 42);
            this.rdb_three_hour.Name = "rdb_three_hour";
            this.rdb_three_hour.Size = new System.Drawing.Size(73, 17);
            this.rdb_three_hour.TabIndex = 2;
            this.rdb_three_hour.TabStop = true;
            this.rdb_three_hour.Text = "За 3 часа";
            this.rdb_three_hour.UseVisualStyleBackColor = true;
            // 
            // rdb_hour
            // 
            this.rdb_hour.AutoSize = true;
            this.rdb_hour.Location = new System.Drawing.Point(97, 19);
            this.rdb_hour.Name = "rdb_hour";
            this.rdb_hour.Size = new System.Drawing.Size(58, 17);
            this.rdb_hour.TabIndex = 1;
            this.rdb_hour.TabStop = true;
            this.rdb_hour.Text = "За час";
            this.rdb_hour.UseVisualStyleBackColor = true;
            // 
            // rdb_real
            // 
            this.rdb_real.AutoSize = true;
            this.rdb_real.Checked = true;
            this.rdb_real.Location = new System.Drawing.Point(6, 19);
            this.rdb_real.Name = "rdb_real";
            this.rdb_real.Size = new System.Drawing.Size(70, 17);
            this.rdb_real.TabIndex = 0;
            this.rdb_real.TabStop = true;
            this.rdb_real.Text = "Как есть";
            this.rdb_real.UseVisualStyleBackColor = true;
            // 
            // btn_build
            // 
            this.btn_build.Enabled = false;
            this.btn_build.Location = new System.Drawing.Point(555, 372);
            this.btn_build.Name = "btn_build";
            this.btn_build.Size = new System.Drawing.Size(215, 43);
            this.btn_build.TabIndex = 26;
            this.btn_build.Text = "Построить график";
            this.btn_build.UseVisualStyleBackColor = true;
            this.btn_build.Click += new System.EventHandler(this.btn_build_Click);
            // 
            // gp_types
            // 
            this.gp_types.Controls.Add(this.rdb_candle);
            this.gp_types.Controls.Add(this.rdb_column);
            this.gp_types.Controls.Add(this.rdb_curve);
            this.gp_types.Location = new System.Drawing.Point(149, 57);
            this.gp_types.Name = "gp_types";
            this.gp_types.Size = new System.Drawing.Size(200, 100);
            this.gp_types.TabIndex = 27;
            this.gp_types.TabStop = false;
            this.gp_types.Text = "Выберите тип графика:";
            // 
            // rdb_curve
            // 
            this.rdb_curve.AutoSize = true;
            this.rdb_curve.Checked = true;
            this.rdb_curve.Location = new System.Drawing.Point(7, 15);
            this.rdb_curve.Name = "rdb_curve";
            this.rdb_curve.Size = new System.Drawing.Size(77, 17);
            this.rdb_curve.TabIndex = 0;
            this.rdb_curve.TabStop = true;
            this.rdb_curve.Text = "Линейный";
            this.rdb_curve.UseVisualStyleBackColor = true;
            // 
            // rdb_column
            // 
            this.rdb_column.AutoSize = true;
            this.rdb_column.Location = new System.Drawing.Point(7, 38);
            this.rdb_column.Name = "rdb_column";
            this.rdb_column.Size = new System.Drawing.Size(85, 17);
            this.rdb_column.TabIndex = 1;
            this.rdb_column.Text = "Столбчатый";
            this.rdb_column.UseVisualStyleBackColor = true;
            // 
            // rdb_candle
            // 
            this.rdb_candle.AutoSize = true;
            this.rdb_candle.Location = new System.Drawing.Point(7, 58);
            this.rdb_candle.Name = "rdb_candle";
            this.rdb_candle.Size = new System.Drawing.Size(107, 17);
            this.rdb_candle.TabIndex = 2;
            this.rdb_candle.Text = "Японские свечи";
            this.rdb_candle.UseVisualStyleBackColor = true;
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1326, 818);
            this.Controls.Add(this.gp_types);
            this.Controls.Add(this.btn_build);
            this.Controls.Add(this.gp_rdb);
            this.Controls.Add(this.LabelEndTime);
            this.Controls.Add(this.LabelBeginTime);
            this.Controls.Add(this.ComboBoxEndTime);
            this.Controls.Add(this.ComboBoxBeginTime);
            this.Controls.Add(this.LabelEndDate);
            this.Controls.Add(this.LabelBeginDate);
            this.Controls.Add(this.DatePickerEnd);
            this.Controls.Add(this.DatePickerBegin);
            this.Controls.Add(this.LabelSensors);
            this.Controls.Add(this.LabelDevices);
            this.Controls.Add(this.ComboBoxSensors);
            this.Controls.Add(this.ComboBoxDevices);
            this.Controls.Add(this.ZGControl);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.grpb_file_types);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "mainForm";
            this.Text = "Построение графиков по данным приборов";
            this.Load += new System.EventHandler(this.mainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpb_file_types.ResumeLayout(false);
            this.grpb_file_types.PerformLayout();
            this.gp_rdb.ResumeLayout(false);
            this.gp_rdb.PerformLayout();
            this.gp_types.ResumeLayout(false);
            this.gp_types.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.RadioButton rdb_csv;
        private System.Windows.Forms.RadioButton rdb_json;
        private System.Windows.Forms.GroupBox grpb_file_types;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private ZedGraph.ZedGraphControl ZGControl;
        private System.Windows.Forms.ComboBox ComboBoxDevices;
        private System.Windows.Forms.ComboBox ComboBoxSensors;
        private System.Windows.Forms.Label LabelDevices;
        private System.Windows.Forms.Label LabelSensors;
        private System.Windows.Forms.DateTimePicker DatePickerBegin;
        private System.Windows.Forms.DateTimePicker DatePickerEnd;
        private System.Windows.Forms.Label LabelBeginDate;
        private System.Windows.Forms.Label LabelEndDate;
        private System.Windows.Forms.ComboBox ComboBoxBeginTime;
        private System.Windows.Forms.ComboBox ComboBoxEndTime;
        private System.Windows.Forms.Label LabelBeginTime;
        private System.Windows.Forms.Label LabelEndTime;
        private System.Windows.Forms.GroupBox gp_rdb;
        private System.Windows.Forms.RadioButton rdb_min_max;
        private System.Windows.Forms.RadioButton rdb_day;
        private System.Windows.Forms.RadioButton rdb_three_hour;
        private System.Windows.Forms.RadioButton rdb_hour;
        private System.Windows.Forms.RadioButton rdb_real;
        private System.Windows.Forms.Button btn_build;
        private System.Windows.Forms.GroupBox gp_types;
        private System.Windows.Forms.RadioButton rdb_candle;
        private System.Windows.Forms.RadioButton rdb_column;
        private System.Windows.Forms.RadioButton rdb_curve;
    }
}

