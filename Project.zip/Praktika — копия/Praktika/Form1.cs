﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
//using System.Windows.Forms.DataVisualization.Charting;
using Newtonsoft.Json.Linq;
using ZedGraph;


namespace Praktika
{
    public partial class mainForm : Form
    {
        BaseOfDevices JBase;
        public mainForm()
        {
            InitializeComponent();
        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            DatePickerBegin.CustomFormat = "dd-MM-yy    HH:mm:ss";
            DatePickerEnd.CustomFormat = "dd-MM-yy    HH:mm:ss";
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Opening t1 = new Opening(chart1, rdb_csv, label1, richTextBox1);
            //t1.OpeningFile();

            var filePath = string.Empty;
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                richTextBox1.Clear();
                JBase = new BaseOfDevices();
                //////////////////
                ComboBoxDevices.Enabled = false;// Делаем недоступными и очищаем комбобоксы до открытия файла
                ComboBoxSensors.Enabled = false;
                ComboBoxBeginTime.Enabled = false;
                ComboBoxEndTime.Enabled = false;
                ComboBoxDevices.ResetText();
                ComboBoxSensors.ResetText();
                ComboBoxBeginTime.ResetText();
                ComboBoxEndTime.ResetText();
                ComboBoxDevices.Items.Clear();
                ComboBoxSensors.Items.Clear();
                ComboBoxBeginTime.Items.Clear();
                ComboBoxEndTime.Items.Clear();

                DatePickerBegin.Enabled = false; // Аналогично с "календарями"
                DatePickerEnd.Enabled = false;
                //DatePickerBegin.ResetText();
                //DatePickerEnd.ResetText();

                openFileDialog.InitialDirectory = "c:\\Users\\User\\Downloads"; //C:\Users\User\Downloads
                if (rdb_csv.Checked == true)
                {
                    openFileDialog.Filter = "Files for reading (*.csv)|*.csv";
                    openFileDialog.RestoreDirectory = true;
                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        filePath = openFileDialog.FileName;
                        MessageBox.Show(filePath, "Choosen file:", MessageBoxButtons.OK);

                        ReadCSV(filePath); //Прочитали CSV
                        AddComboBoxDevices(); //По данным файла добавляем в данной ситуации одну строчку в комбобоксе
                    }
                }
                else
                {
                    openFileDialog.Filter = "Files for reading (*.json, *.JSON)|*.json;*.JSON";
                    openFileDialog.RestoreDirectory = true;
                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        filePath = openFileDialog.FileName;
                        MessageBox.Show(filePath, "Choosen file:", MessageBoxButtons.OK);

                        ReadJSON(filePath);
                        AddComboBoxDevices();
                    }
                }
            }
        }

        private void ComboBoxDevices_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBoxSensors.Items.Clear();
            ComboBoxBeginTime.Items.Clear();
            ComboBoxEndTime.Items.Clear();
            DatePickerBegin.Enabled = false;
            DatePickerEnd.Enabled = false;
            ComboBoxBeginTime.Enabled = false;
            ComboBoxEndTime.Enabled = false;
            gp_rdb.Enabled = false;
            btn_build.Enabled = false;
            AddComboBoxSensors();
            ComboBoxSensors.Enabled = true;
            ComboBoxSensors.ResetText();
        }

        private void ComboBoxSensors_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadDateTime();
            DatePickerBegin.Enabled = true;
        }

        private void btn_build_Click(object sender, EventArgs e)
        {
            int indexOfChosenElemInComBox = ComboBoxDevices.SelectedIndex; //Индекс выбранного в комбобоксе прибора
            int indexOfDevice = JBase.ReturnIndexOfDevice(ComboBoxDevices.Items[indexOfChosenElemInComBox].ToString()); //Находим в словаре номер прибора, выбранного в комбобоксе
            Device device = JBase.ReturnObj(indexOfDevice); //Возвращаем объект прибора по индексу

            List<double> SensorData = new List<double>(); //Лист для данных датчика
            List<DateTime> Date = new List<DateTime>(); //Создаём лист удобного типа данных
            int indexofsensor = device.FindSensorIndex(ComboBoxSensors.SelectedItem.ToString());

            DateTime intervalBegin = DatePickerBegin.Value; //Находим границы временного интервала
            DateTime intervalEnd = DatePickerEnd.Value;
            string intervalBegin_str = ChangeFormat(intervalBegin.ToString());
            string intervalEnd_str = ChangeFormat(intervalEnd.ToString());
            int startInterval = device.FindDateIndexBegin(intervalBegin_str);
            int endInterval = device.FindDateIndexEnd(intervalEnd_str);

            for (int i = startInterval; i < endInterval; i++) //Заполняем листы датой и данными
            {
                Date.Add(DateTime.Parse(device.GetTable()[i][0]));
                SensorData.Add(double.Parse(device.GetTable()[i][indexofsensor], System.Globalization.CultureInfo.InvariantCulture));
            }

            ZGControl.GraphPane.CurveList.Clear();
            ZGControl.GraphPane.YAxis.Title.Text = ComboBoxSensors.SelectedItem.ToString();
            ZGControl.GraphPane.XAxis.Type = AxisType.Date;
            ZGControl.GraphPane.XAxis.Scale.Format = "yyyy-MM-dd HH:mm:ss";
            ZGControl.GraphPane.XAxis.Scale.FontSpec.Angle = 90;
            ZGControl.GraphPane.XAxis.Scale.FontSpec.Size = 12;
            ZGControl.GraphPane.XAxis.Scale.MajorUnit = DateUnit.Second;
            ZGControl.GraphPane.XAxis.Scale.MajorStep = 3;
            ZGControl.GraphPane.XAxis.Scale.MinorUnit = DateUnit.Second;
            ZGControl.GraphPane.XAxis.Scale.MinorStep = 1;

            List<DateTime> XAxis = new List<DateTime>();
            List<double> YAxis = new List<double>();

            if (rdb_real.Checked == true)
            {
                //var myCurve = canvas.GraphPane.AddCurve(nameOfSeries, PointList, Color.Red);
                //myCurve.Line.IsAntiAlias = true;
                //myCurve.Symbol.IsVisible = false;
                XAxis = Date;
                YAxis = SensorData;
            }
            if (rdb_hour.Checked == true)
            {
                DateTime tmp = new DateTime();
                tmp = Date[0];
                tmp = tmp.AddHours(1);

                int counter = 0;
                while(Date[counter] <= tmp)
                {
                    counter++;
                }
                double sum = 0;
                for (int i = 1; i < SensorData.Count; i++)
                {
                    sum += SensorData[i];
                    if (i % counter == 0)
                    {
                        sum /= counter;
                        XAxis.Add(Date[i]);
                        YAxis.Add(sum);
                        sum = 0;
                    }
                }
            }
            if (rdb_three_hour.Checked == true)
            {
                DateTime tmp = new DateTime();
                tmp = Date[0];
                tmp = tmp.AddHours(3);

                int counter = 0;
                while (Date[counter] <= tmp)
                {
                    counter++;
                }
                double sum = 0;
                for (int i = 1; i < SensorData.Count; i++)
                {
                    sum += SensorData[i];
                    if (i % counter == 0)
                    {
                        sum /= counter;
                        XAxis.Add(Date[i]);
                        YAxis.Add(sum);
                        sum = 0;
                    }
                }
            }
            if (rdb_day.Checked == true)
            {
                DateTime tmp = new DateTime();
                tmp = Date[0];
                tmp = tmp.AddDays(1);

                int counter = 0;
                while (Date[counter] <= tmp)
                {
                    counter++;
                }
                double sum = 0;
                for (int i = 1; i < SensorData.Count; i++)
                {
                    sum += SensorData[i];
                    if (i % counter == 0)
                    {
                        sum /= counter;
                        XAxis.Add(Date[i]);
                        YAxis.Add(sum);
                        sum = 0;
                    }
                }
            }
            if (rdb_min_max.Checked == true)
            {
                DateTime tmp = new DateTime();
                tmp = Date[0];
                tmp = tmp.AddDays(1);

                int counter = 0;
                while (Date[counter] <= tmp)
                {
                    counter++;
                }

                double min_value = SensorData[0];
                double max_value = -99999;
                int max_index = 0;
                int min_index = 0;

                int k = 0;
                for(int i = 1; i < SensorData.Count/counter; i++)
                {
                    for(int j = 0; j < counter; j++)
                    {
                        if (SensorData[k] > max_value)
                        {
                            max_value = SensorData[k];
                            max_index = k;
                        }
                        if (SensorData[k] < min_value)
                        {
                            min_value = SensorData[k];
                            min_index = k;
                        }
                        k++;
                    }

                    if (Date[max_index] > Date[min_index])
                    {
                        XAxis.Add(Date[min_index]);
                        YAxis.Add(min_value);
                        XAxis.Add(Date[max_index]);
                        YAxis.Add(max_value);
                    }
                    else
                    {
                        XAxis.Add(Date[max_index]);
                        YAxis.Add(max_value);
                        XAxis.Add(Date[min_index]);
                        YAxis.Add(min_value);
                    }
                    min_value = SensorData[k + 1];
                    max_value = -99999;

                }
            }

            PointPairList PointList = new PointPairList();
            for (int i = 0; i < XAxis.Count; i++)
            {
                PointList.Add(new XDate(XAxis[i]), YAxis[i]);
            }
            string nameOfSeries = ComboBoxSensors.SelectedItem.ToString();
            if(rdb_curve.Checked == true)
            {
                var curve = ZGControl.GraphPane.AddCurve(nameOfSeries, PointList, Color.Red);
                curve.Line.IsAntiAlias = true;
                curve.Symbol.IsVisible = false;
            }
            if(rdb_column.Checked == true)
            {
                var bar = ZGControl.GraphPane.AddBar(nameOfSeries, PointList, Color.Red);
            }
            if(rdb_candle.Checked == true)
            {
                var candle = ZGControl.GraphPane.AddJapaneseCandleStick(nameOfSeries, PointList);
            }
            ZGControl.AxisChange();
            ZGControl.Refresh();
        }

        private void DatePickerBegin_ValueChanged(object sender, EventArgs e)
        {
            DatePickerEnd.Enabled = true;
            gp_rdb.Enabled = true;
            btn_build.Enabled = true;
        }

        private void DatePickerEnd_ValueChanged(object sender, EventArgs e)
        {
            //AddComBoxBeginTime();
        }

        void ReadCSV(string f_filePath)
        {
            var reader = new StreamReader(f_filePath);
            var UNameLine = reader.ReadLine(); //Читаем первую строку CSV файла, в которой есть uName
            Device device = new Device();
            device.SetUName(UNameLine.Split(';')[1]); //Достаём из первой прочитанной строки uName и кладём в класс
            var SNameLine = reader.ReadLine(); //Читаем вторую строку с названиями датчиков
            device.SetWidth(SNameLine); //Находим ширину "таблицы"
            for (int i = 0; i < device.GetWidth(); i++)
            {
                device.SetSensorName(SNameLine.Split(';')[i]); //Кладём названия датчиков в класс(в лист с названиями датчиков)
            }
            int stroki = 0;
            while (!reader.EndOfStream) // Цикл для заполнения таблицы данными с датчиков
            {
                var dataLine = reader.ReadLine();
                device.CreateTableString();
                for (int i = 0; i < device.GetWidth(); i++)
                {
                    device.SetData(stroki, dataLine.Split(';')[i]);
                }
                stroki++;
            }
            #region printing
            //lab1.Text = csvObj.uName + csvObj.widthOfTable;
            //for (int i = 0; i < csvObj.GetWidth(); i++)
            //{
            //    lab1.Text += csvObj.SensorsName[i];
            //}
            //lab1.Text += '\n';
            //for (int i = 0; i < csvObj.GetTable().Count; i++)
            //{
            //    for (int j = 0; j < csvObj.GetTable()[i].Count; j++)
            //    {
            //        rc1.Text += csvObj.GetTable()[i][j] + " ";
            //    }
            //    rc1.Text += "\n";
            //    //rc1.Text += csvObj.GetTable()[i][i] + " ";
            //}
            #endregion

            JBase.ReturnList().Add(new Device());
            JBase.AddDictionaryElem(device.GetUName(), 0); //Кладём имя прибора в словарь
            JBase.SetObj(device, 0); //Кладём прибор в лист приборов нашей базы
        }
        void ReadJSON(string f_filePath)
        {
            string myJsonString = File.ReadAllText(f_filePath);
            try
            {
                JObject myJObject = JObject.Parse(myJsonString);

                int sizeDictionary = 0;
                foreach (var item in myJObject)
                {
                    if (JBase.GetDictionary().ContainsKey(item.Value["uName"].ToString()) == false) // Проверяем был ли уже прибор в словаре
                    {
                        JBase.AddDictionaryElem(item.Value["uName"].ToString(), sizeDictionary); //Добавляем имя прибора в словарь
                        sizeDictionary++;

                        Device device = new Device();
                        device.SetUName(item.Value["uName"].ToString()); //В csv объект записываем имя прибора

                        device.CreateTableString(); //Создали строку для "таблицы"
                        int widthOfTable = 1; // Стоит 1, так как дата будет в первом столбце

                        device.SetSensorName("Date"); // В первый столбец листа с именами датчиков кладём название "Date"
                        device.SetData(device.GetTable().Count - 1, item.Value["Date"].ToString()); // В первый столбец первой строки "таблицы" кладём дату в формате string  || -1 надо иначе всё сломается
                                                                                                    //(это из - за того что в листе ячейки начинаются с 0)
                        foreach (JProperty tmp in item.Value["data"].Children()) // Цикл пробегает по всем токенам у "data"
                        {
                            widthOfTable++;
                            device.SetSensorName(tmp.Name.ToString()); //В лист с именами датчиков кладутся токены
                            device.SetData(0, tmp.Last.ToString()); //В первую строчку "таблицы" кладутся значения токенов(в первую, так как это первое появление прибора)
                            device.SetWidth(widthOfTable); //в объект кладётся ширина "таблицы"
                        }

                        JBase.SetObj(device); //Возвращаем csv объект в лист List<CSV_Base> JB_Objects, содержащий каждый прибор с его измерениями
                                              //rc1.Text += "End of pribor \n\n";
                    }
                    else
                    {
                        int indexOfDevice = JBase.ReturnIndexOfDevice(item.Value["uName"].ToString()); //Получаем индекс прибора в словаре
                        Device device = JBase.ReturnObj(indexOfDevice); //Достаём из листа приборов прибор по индексу в словаре

                        device.CreateTableString(); //Создали строку под новые данные

                        device.SetData(device.GetTable().Count - 1, item.Value["Date"].ToString()); //В последнюю строку в первый столбец записали дату

                        foreach (JProperty tmp in item.Value["data"].Children())
                        {
                            device.SetData(device.GetTable().Count - 1, tmp.Last.ToString()); //В последнюю строку "таблицы" кладётся значение с                         
                        }
                        #region printing
                        //for (int i = 0; i < csvObj.GetTable().Count; i++)
                        //{
                        //    for (int j = 0; j < csvObj.GetTable()[i].Count; j++)
                        //    {
                        //        rc1.Text += csvObj.GetTable()[i][j] + " ";
                        //    }
                        //    rc1.Text += "\n";
                        //    //rc1.Text += csvObj.GetTable()[i][i] + " ";
                        //}
                        #endregion

                        JBase.SetObj(device, indexOfDevice);//Возвращаем csv объект в лист List<CSV_Base> JB_Objects, содержащий каждый прибор с его измерениями
                    }
                }
            } catch (Newtonsoft.Json.JsonReaderException e)
            {
                //MessageBox.Show(filePath, "Choosen file:", MessageBoxButtons.OK);
                MessageBox.Show("Error reading from json file. Message : " + e.ToString());
            }
            #region beta version
            //JObject myJObject = JObject.Parse(myJsonString);

            //int sizeDictionary = 0;
            //foreach (var item in myJObject)
            //{
            //    if (JBase.GetDictionary().ContainsKey(item.Value["uName"].ToString()) == false) // Проверяем был ли уже прибор в словаре
            //    {
            //        JBase.AddDictionaryElem(item.Value["uName"].ToString(), sizeDictionary); //Добавляем имя прибора в словарь
            //        sizeDictionary++;
            //        //rc1.Text += item.Value + "\n";

            //        Device device = new Device();
            //        device.SetUName(item.Value["uName"].ToString()); //В csv объект записываем имя прибора

            //        device.CreateTableString(); //Создали строку для "таблицы"
            //        int widthOfTable = 1; // Стоит 1, так как дата будет в первом столбце

            //        device.SetSensorName("Date"); // В первый столбец листа с именами датчиков кладём название "Date"
            //        device.SetData(device.GetTable().Count - 1, item.Value["Date"].ToString()); // В первый столбец первой строки "таблицы" кладём дату в формате string  || -1 надо иначе всё сломается
            //                                                                                    //(это из - за того что в листе ячейки начинаются с 0)
            //        foreach (JProperty tmp in item.Value["data"].Children()) // Цикл пробегает по всем токенам у "data"
            //        {
            //            widthOfTable++;
            //            device.SetSensorName(tmp.Name.ToString()); //В лист с именами датчиков кладутся токены
            //            device.SetData(0, tmp.Last.ToString()); //В первую строчку "таблицы" кладутся значения токенов(в первую, так как это первое появление прибора)
            //            device.SetWidth(widthOfTable); //в объект кладётся ширина "таблицы"

            //            //rc1.Text += tmp.Name + " " + tmp.Last + "\n";
            //        }
            //        #region
            //        //for (int i = 0; i < csvObj.GetTable().Count; i++)
            //        //{
            //        //    for (int j = 0; j < csvObj.GetTable()[i].Count; j++)
            //        //    {
            //        //        rc1.Text += csvObj.GetTable()[i][j] + " ";
            //        //    }
            //        //    rc1.Text += "\n";
            //        //    //rc1.Text += csvObj.GetTable()[i][i] + " ";
            //        //}
            //        #endregion

            //        JBase.SetObj(device); //Возвращаем csv объект в лист List<CSV_Base> JB_Objects, содержащий каждый прибор с его измерениями
            //                              //rc1.Text += "End of pribor \n\n";
            //    }
            //    else
            //    {
            //        int indexOfDevice = JBase.ReturnIndexOfDevice(item.Value["uName"].ToString()); //Получаем индекс прибора в словаре
            //        Device device = JBase.ReturnObj(indexOfDevice); //Достаём из листа приборов прибор по индексу в словаре

            //        device.CreateTableString(); //Создали строку под новые данные

            //        device.SetData(device.GetTable().Count - 1, item.Value["Date"].ToString()); //В последнюю строку в первый столбец записали дату

            //        foreach (JProperty tmp in item.Value["data"].Children())
            //        {
            //            device.SetData(device.GetTable().Count - 1, tmp.Last.ToString()); //В последнюю строку "таблицы" кладётся значение с                         
            //        }
            //        #region printing
            //        //for (int i = 0; i < csvObj.GetTable().Count; i++)
            //        //{
            //        //    for (int j = 0; j < csvObj.GetTable()[i].Count; j++)
            //        //    {
            //        //        rc1.Text += csvObj.GetTable()[i][j] + " ";
            //        //    }
            //        //    rc1.Text += "\n";
            //        //    //rc1.Text += csvObj.GetTable()[i][i] + " ";
            //        //}
            //        #endregion

            //        JBase.SetObj(device, indexOfDevice);//Возвращаем csv объект в лист List<CSV_Base> JB_Objects, содержащий каждый прибор с его измерениями
            //    }
            //}
            #endregion
            #region printing
            //for (int i = 0; i < JBase.GetDictionary().Count; i++)
            //{
            //    Device tmp = JBase.ReturnObj(i);
            //    for (int k = 0; k < tmp.GetTable().Count; k++)
            //    {
            //        for (int j = 0; j < tmp.GetTable()[k].Count; j++)
            //        {
            //            richTextBox1.Text += tmp.GetTable()[k][j] + " ";
            //        }
            //        richTextBox1.Text += "\n";
            //        //rc1.Text += csvObj.GetTable()[i][i] + " ";
            //    }
            //    richTextBox1.Text += "\n\n";
            //}
            #endregion
        }
        void AddComboBoxDevices() //После открытия файла добавляет в комбо-бокс строчки с названиями приборов
        {
            for (int i = 0; i < JBase.GetDictionary().Count; i++)
            {
                ComboBoxDevices.Items.Add(JBase.GetNameFromDictionaryWithIndex(i));
            }

            ComboBoxDevices.Enabled = true;
        }
        void AddComboBoxSensors() //После выбора прибора добавляет в ComboBoxSensors названия датчиков
        {
            int indexOfDevice = JBase.ReturnIndexOfDevice(ComboBoxDevices.SelectedItem.ToString()); //Находим в словаре номер прибора, выбранного в комбобоксе
            Device device = JBase.ReturnObj(indexOfDevice); //Возвращаем объект прибора по индексу
            int amountOfSensors = device.GetWidth(); //Кол-во датчиков
            for (int j = 0; j < amountOfSensors; j++) //Цикл сначала проверяет первую строчку на наличие double-значения, если в столбце есть такое, то второй файл проверяет весь стобец на "битость"
            {
                if(double.TryParse(device.GetTable()[0][j], System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out double result) == true)
                {
                    bool flag = true;
                    for (int i = 0; i < device.GetTable().Count; i++)
                    {
                        if(double.TryParse(device.GetTable()[i][j], System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out double rez) == false)
                        {
                            flag = false;
                            device.AddZeroElem(i, j);
                            //richTextBox1.Text += device.GetTable()[i][j] + "\n";
                        }
                    }
                    if(flag == true)
                    {
                        ComboBoxSensors.Items.Add(device.GetSensorName()[j].ToString());
                    }
                }
            }
        }

        void LoadDateTime()
        {
            int indexOfDevice = JBase.ReturnIndexOfDevice(ComboBoxDevices.SelectedItem.ToString()); //Находим в словаре номер прибора, выбранного в комбобоксе
            Device device = JBase.ReturnObj(indexOfDevice); //Возвращаем объект прибора по индексу
            //for (int i = 0; i < device.GetTable().Count; i++)
            //{
            //    richTextBox1.Text += device.GetTable()[i][0] + "\n";
            //}
            string startDate = device.GetTable()[0][0].ToString();
            string endDate = device.GetTable()[device.GetTable().Count-1][0].ToString();

            DateTime minDate, maxDate;
            minDate = DateTime.Parse(startDate);
            maxDate = DateTime.Parse(endDate);

            DatePickerBegin.MinDate = new DateTime(1985, 6, 20);
            DatePickerBegin.MaxDate = new DateTime(2100, 12, 31);
            DatePickerBegin.MinDate = minDate;
            DatePickerBegin.MaxDate = maxDate;
            DatePickerBegin.Value = minDate;

            DatePickerEnd.MinDate = new DateTime(1985, 6, 20);
            DatePickerEnd.MaxDate = new DateTime(2100, 12, 31);
            DatePickerEnd.MinDate = minDate;
            DatePickerEnd.MaxDate = maxDate;
            DatePickerEnd.Value = maxDate;
        }
        /*void AddComBoxBeginTime()
        {
            string datebegin = ChangeFormat(DatePickerBegin.Value.ToString());
            string dateend = ChangeFormat(DatePickerEnd.Value.ToString());

            int indexOfChosenElemInComBox = ComboBoxDevices.SelectedIndex; //Индекс выбранного в комбобоксе прибора
            int indexOfDevice = JBase.ReturnIndexOfDevice(ComboBoxDevices.Items[indexOfChosenElemInComBox].ToString()); //Находим в словаре номер прибора, выбранного в комбобоксе
            Device device = JBase.ReturnObj(indexOfDevice); //Возвращаем объект прибора по индексу

            int datebeginindex = device.FindDateIndexBegin(datebegin);
            int dateendindex = device.FindDateIndexEnd(dateend);
            string datebegin1 = datebegin;
            //for (int i = datebeginindex; i < dateendindex + 1; i++)
            //{
            //    ComboBoxBeginTime.Items.Add(device.GetTable()[i][0].ToString());
            //}
            //for (int i = datebeginindex; DatePickerBegin.Value < DatePickerBegin.Value.AddDays(1); i++)
            //{
            //    ComboBoxBeginTime.Items.Add(device.GetTable()[i][0].ToString());
            //}
        }*/
        string ChangeFormat(string str)
        {
            char[] charStr = new char[str.Length];
            for (int i = 0; i < str.Length; i++)
            {
                if(str[i] == '.')
                {
                    charStr[i] = '-';
                } else
                {
                    charStr[i] = str[i];
                }
            }

            string result;

            char[] edited = new char[charStr.Length + 1];
            if (charStr[10] == ' ' && charStr[12] == ':')
            {
                for(int i = 0; i < 10; i++)
                {
                    edited[i] = charStr[i];
                }
                edited[10] = ' ';
                edited[11] = '0';
                edited[12] = charStr[11];
                for (int i = 13; i < edited.Length; i++)
                {
                    edited[i] = charStr[i - 1];
                }
                #region brootforce
                char tmp0 = charStr[0]; //Меняет формат dd-mm-yyyy на yyyy-mm-dd
                char tmp1 = charStr[1]; //Это будет изменено на нормальный алгоритм или упрощено, но пока что так из-за сроков
                char tmp2 = charStr[2];
                char tmp3 = charStr[3];
                char tmp4 = charStr[4];
                char tmp5 = charStr[5];
                char tmp6 = charStr[6];
                char tmp7 = charStr[7];
                char tmp8 = charStr[8];
                char tmp9 = charStr[9];

                edited[0] = tmp6;
                edited[1] = tmp7;
                edited[2] = tmp8;
                edited[3] = tmp9;
                edited[4] = tmp2;
                edited[5] = tmp3;
                edited[6] = tmp4;
                edited[7] = tmp5;
                edited[8] = tmp0;
                edited[9] = tmp1;
                #endregion
                result = new string(edited);
            } else
            {
                #region brootforce
                char tmp0 = charStr[0]; //Меняет формат dd-mm-yyyy hh:mm:ss на yyyy-mm-dd hh:mm:ss
                char tmp1 = charStr[1]; //Это будет изменено на нормальный алгоритм или упрощено, но пока что так из-за сроков
                char tmp2 = charStr[2];
                char tmp3 = charStr[3];
                char tmp4 = charStr[4];
                char tmp5 = charStr[5];
                char tmp6 = charStr[6];
                char tmp7 = charStr[7];
                char tmp8 = charStr[8];
                char tmp9 = charStr[9];

                edited[0] = tmp6;
                edited[1] = tmp7;
                edited[2] = tmp8;
                edited[3] = tmp9;
                edited[4] = tmp2;
                edited[5] = tmp3;
                edited[6] = tmp4;
                edited[7] = tmp5;
                edited[8] = tmp0;
                edited[9] = tmp1;

                for (int i = 10; i < edited.Length-1; i++)
                {
                    edited[i] = charStr[i];
                }
                char[] res = new char[edited.Length - 1];
                for (int i = 0; i < res.Length; i++)
                {
                    res[i] = edited[i];
                }
                result = new string(res);
                #endregion
            }

            return result;
        }
    }
}
