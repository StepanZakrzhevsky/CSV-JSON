﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Windows.Forms.DataVisualization.Charting;
using Newtonsoft.Json.Linq;

//namespace Praktika
//{
//    public class Opening
//    {
//        Chart chart1;
//        RadioButton rdb_csv;
//        Label lab1;
//        RichTextBox rc1;
//        public Opening(Chart c1, RadioButton r1, Label l, RichTextBox rich1)
//        {
//            chart1 = c1;
//            rdb_csv = r1;
//            lab1 = l;
//            rc1 = rich1;
//        }
//        public void OpeningFile()
//        {
//            var filePath = string.Empty;
//            using (OpenFileDialog openFileDialog = new OpenFileDialog())
//            {
//                rc1.Clear();
//                openFileDialog.InitialDirectory = "c:\\Users\\User\\Downloads"; //C:\Users\User\Downloads
//                if (rdb_csv.Checked == true)
//                {
//                    openFileDialog.Filter = "Files for reading (*.csv)|*.csv";
//                    openFileDialog.RestoreDirectory = true;
//                    if (openFileDialog.ShowDialog() == DialogResult.OK)
//                    {
//                        filePath = openFileDialog.FileName;
//                        MessageBox.Show(filePath, "Choosen file:", MessageBoxButtons.OK);
                        
//                        ReadCSV(filePath); 
//                    }
//                }
//                else
//                {
//                    openFileDialog.Filter = "Files for reading (*.json, *.JSON)|*.json;*.JSON";
//                    openFileDialog.RestoreDirectory = true;
//                    if (openFileDialog.ShowDialog() == DialogResult.OK)
//                    {
//                        filePath = openFileDialog.FileName;
//                        MessageBox.Show(filePath, "Choosen file:", MessageBoxButtons.OK);

//                        ReadJSON(filePath);
//                    }
//                }
//            }
//        }

//        Device ReadCSV(string f_filePath)
//        {
//            var reader = new StreamReader(f_filePath);
//            var UNameLine = reader.ReadLine(); //Читаем первую строку CSV файла, в которой есть uName
//            Device csvObj = new Device();
//            csvObj.SetUName(UNameLine.Split(';')[1]); //Достаём из первой прочитанной строки uName и кладём в класс
//            var SNameLine = reader.ReadLine(); //Читаем вторую строку с названиями датчиков
//            csvObj.SetWidth(SNameLine); //Находим ширину "таблицы"
//            for (int i = 0; i < csvObj.GetWidth(); i++)
//            {
//                csvObj.SetSensorName(SNameLine.Split(';')[i]); //Кладём названия датчиков в класс(в лист с названиями датчиков)
//            }
//            int stroki = 0;
//            while (!reader.EndOfStream) // Цикл для заполнения таблицы данными с датчиков
//            {
//                var dataLine = reader.ReadLine();
//                csvObj.CreateTableString();
//                for (int i = 0; i < csvObj.GetWidth(); i++)
//                {
//                    csvObj.SetData(stroki, dataLine.Split(';')[i]);
//                }
//                stroki++;
//            }

//            //lab1.Text = csvObj.uName + csvObj.widthOfTable;
//            //for (int i = 0; i < csvObj.GetWidth(); i++)
//            //{
//            //    lab1.Text += csvObj.SensorsName[i];
//            //}
//            //lab1.Text += '\n';
//            //for (int i = 0; i < csvObj.GetTable().Count; i++)
//            //{
//            //    for (int j = 0; j < csvObj.GetTable()[i].Count; j++)
//            //    {
//            //        rc1.Text += csvObj.GetTable()[i][j] + " ";
//            //    }
//            //    rc1.Text += "\n";
//            //    //rc1.Text += csvObj.GetTable()[i][i] + " ";
//            //}

//            return csvObj;
//        }

//        void ReadJSON(string f_filePath)
//        {
//            string myJsonString = File.ReadAllText(f_filePath);
//            JObject myJObject = JObject.Parse(myJsonString);
//            BaseOfDevices JBase = new BaseOfDevices();

//            int sizeDictionary = 0;
//            foreach (var item in myJObject)
//            {
//                if (JBase.GetDictionary().ContainsKey(item.Value["uName"].ToString()) == false) // Проверяем был ли уже прибор в словаре
//                {
//                    JBase.AddDictionaryElem(item.Value["uName"].ToString(), sizeDictionary); //Добавляем имя прибора в словарь
//                    sizeDictionary++;
//                    //rc1.Text += item.Value + "\n";

//                    Device device = new Device();
//                    device.SetUName(item.Value["uName"].ToString()); //В csv объект записываем имя прибора

//                    device.CreateTableString(); //Создали строку для "таблицы"
//                    int widthOfTable = 1; // Стоит 1, так как дата будет в первом столбце

//                    device.SetSensorName("Date"); // В первый столбец листа с именами датчиков кладём название "Date"
//                    device.SetData(device.GetTable().Count-1, item.Value["Date"].ToString()); // В первый столбец первой строки "таблицы" кладём дату в формате string  || -1 надо иначе всё сломается
//                                                                                                                                                                            //(это из - за того что в листе ячейки начинаются с 0)
//                    foreach (JProperty tmp in item.Value["data"].Children()) // Цикл пробегает по всем токенам у "data"
//                    {
//                        widthOfTable++;
//                        device.SetSensorName(tmp.Name.ToString()); //В лист с именами датчиков кладутся токены
//                        device.SetData(0, tmp.Last.ToString()); //В первую строчку "таблицы" кладутся значения токенов(в первую, так как это первое появление прибора)
//                        device.SetWidth(widthOfTable); //Пока никак не используется, но в объект кладётся ширина "таблицы"

//                        //rc1.Text += tmp.Name + " " + tmp.Last + "\n";
//                    }
//                    #region
//                    //for (int i = 0; i < csvObj.GetTable().Count; i++)
//                    //{
//                    //    for (int j = 0; j < csvObj.GetTable()[i].Count; j++)
//                    //    {
//                    //        rc1.Text += csvObj.GetTable()[i][j] + " ";
//                    //    }
//                    //    rc1.Text += "\n";
//                    //    //rc1.Text += csvObj.GetTable()[i][i] + " ";
//                    //}
//                    #endregion

//                    JBase.SetObj(device); //Возвращаем csv объект в лист List<CSV_Base> JB_Objects, содержащий каждый прибор с его измерениями
//                    //rc1.Text += "End of pribor \n\n";
//                } else
//                {
//                    int indexOfDevice = JBase.ReturnIndexOfDevice(item.Value["uName"].ToString()); //Получаем индекс прибора в словаре
//                    Device csvObj = JBase.ReturnObj(indexOfDevice); //Достаём из листа приборов прибор по индексу в словаре

//                    csvObj.CreateTableString(); //Создали строку под новые данные
//                    int widthOfTable = csvObj.GetWidth(); //Получили ширину "таблицы"

//                    csvObj.SetData(csvObj.GetTable().Count-1, item.Value["Date"].ToString()); //В последнюю строку в первый столбец записали дату

//                    foreach (JProperty tmp in item.Value["data"].Children())
//                    {
//                        widthOfTable++;
//                        //csvObj.SetSensorName(tmp.Name.ToString());
//                        csvObj.SetData(csvObj.GetTable().Count-1, tmp.Last.ToString()); //В последнюю строку "таблицы" кладётся значение с датчика
//                        csvObj.SetWidth(widthOfTable);  //Пока никак не используется, но в объект кладётся ширина "таблицы"
//                    }
//                    #region
//                    //for (int i = 0; i < csvObj.GetTable().Count; i++)
//                    //{
//                    //    for (int j = 0; j < csvObj.GetTable()[i].Count; j++)
//                    //    {
//                    //        rc1.Text += csvObj.GetTable()[i][j] + " ";
//                    //    }
//                    //    rc1.Text += "\n";
//                    //    //rc1.Text += csvObj.GetTable()[i][i] + " ";
//                    //}
//                    #endregion

//                    JBase.SetObj(csvObj, indexOfDevice);//Возвращаем csv объект в лист List<CSV_Base> JB_Objects, содержащий каждый прибор с его измерениями
//                }
//            }

//            #region
//            for (int i = 0; i < JBase.GetDictionary().Count; i++)
//            {
//                Device tmp = JBase.ReturnObj(i);
//                for (int k = 0; k < tmp.GetTable().Count; k++)
//                {
//                    for (int j = 0; j < tmp.GetTable()[k].Count; j++)
//                    {
//                        rc1.Text += tmp.GetTable()[k][j] + " ";
//                    }
//                    rc1.Text += "\n";
//                    //rc1.Text += csvObj.GetTable()[i][i] + " ";
//                }
//                rc1.Text += "\n\n";
//            }
//            #endregion
//        }
//    }
//}


//List<double> listX = new List<double>();
//List<double> listY = new List<double>();
//int t = 0;
//var myJsonString = File.ReadAllText(fopen.Filename);
//var myJObject = JObject.Parse(myJsonString);
//foreach (var item in myJObject)
//{
//    if (item.Value["uName"].ToString() == "Тест Студии")
//    {
//        var str = item.Value["data"].SelectToken("BMP280_temp").ToString();
//        listX.Add(t);
//        listY.Add(Convert.ToDouble(str));
//        t++;
//    }
//}


//var reader = new StreamReader(filePath);
//List<double> listX = new List<double>();
//List<double> listY = new List<double>();
//int t = 0;

//var myJsonString = File.ReadAllText(filePath);
//var myJObject = JObject.Parse(myJsonString);
//JSON_Base JBObject = new JSON_Base();

//Dictionary<int, string> Names = new Dictionary<int, string>();


//int sizeDictionary = 0;
//foreach (var item in myJObject)
//{
//    if (JBObject.getDictionary().ContainsValue(item.Value["uName"].ToString()) == false)
//    {
//        JBObject.getDictionary().Add(sizeDictionary, item.Value["uName"].ToString());
//        sizeDictionary++;
//    }
//}
//foreach (var item in myJObject)
//{
//    if (item.Value["uName"].ToString() == "Hydra-L")
//    {
//        //var str = item.Value["data"].SelectToken("BME280_temp").ToString();
//        //listX.Add(t);
//        //listY.Add(Convert.ToDouble(str));
//        //listY.Add(double.Parse(str, System.Globalization.CultureInfo.InvariantCulture));
//        //t++;
//    }
//}

//string seriesName = "Temperature";
//chart1.Series.Add(seriesName);
//chart1.Series[seriesName].ChartType = SeriesChartType.Line;
//chart1.Series[seriesName].BorderWidth = 5;
//for (int i = 0; i < listY.Count; i++)
//{
//    double XVal = listX[i];
//    double YVal = listY[i];
//    chart1.Series[seriesName].Points.AddXY(XVal, YVal);
//}