﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktika
{
    class Device
    {
        public Device()
        {
            widthOfTable = 0;
        }

        private string uName; // Название прибора
        private List<string> SensorsName = new List<string>(); // Лист с названиями датчиков
        private List<List<string>> Table = new List<List<string>>(); // Просто таблица с данными(индекс в листе с названиями датчиков соответствует индексу в таблице)
        private int widthOfTable;                                    // Например влажность первая в SensorName, значит и данные влажности в первом столбце

        public void SetUName(string str)
        {
            uName = str;
        }
        public string GetUName()
        {
            return uName;
        }
        public void SetWidth(string str)
        {
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == ';') widthOfTable++;
            }
        } //Получение ширины таблицы(кол-во столбцов)
        public void SetWidth(int width)
        {
            widthOfTable = width;
        }
        public void SetSensorName(string str)
        {
            SensorsName.Add(str);
        }
        public void SetData(int strok, string str)
        {
            Table[strok].Add(str);
        }
        public int GetWidth()
        {
            return widthOfTable;
        }
        public void CreateTableString()
        {
            Table.Add(new List<string>());
        } //Выделение памяти под новую строчку
        public List<List<string>> GetTable() //Получение таблицы с данными для чтения
        {
            return Table;
        }
        public List<string> GetSensorName() //Получение списка датчиков для чтения
        {
            return SensorsName;
        }
        public int FindDateIndexBegin(string str)//Поиск номера строки с датой с начала массива
        //(просто бывает, что в массиве есть повторяющиеся даты замеров(такое бывает, когда две серии делают замер))
        {
            for (int i = 0; i < Table.Count; i++)
            {
                if (Table[i][0] == str)
                {
                    return i;
                }
            }

            return -1;
        }
        public int FindDateIndexEnd(string str)//Поиск номера строки с датой с конца массива
        {
            for (int i = Table.Count-1; i > -1; i--)
            {
                if (Table[i][0] == str)
                {
                    return i;
                }
            }

            return -1;
        }
        public int FindSensorIndex(string str)
        {
            for (int i = 0; i < SensorsName.Count; i++)
            {
                if (SensorsName[i] == str)
                {
                    return i;
                }
            }

            return -1;
        }
        public void AddZeroElem(int i, int j) //Если встретилось значение, которое не парсится в double, то зануляем его
        {
            Table[i][j] = "0";
        }
    }
}