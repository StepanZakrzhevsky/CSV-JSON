﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktika
{
    class BaseOfDevices
    {
        public BaseOfDevices()
        {

        }

        private Dictionary<string, int> Names = new Dictionary<string, int>(); //Словарь с названиями приборов
        private List<Device> JB_Objects = new List<Device>(); //Список приборов

        public Dictionary<string, int> GetDictionary() //Получение словаря для чтения
        {
            return Names;
        } 
        public void AddDictionaryElem(string str, int k) //Добавление нового прибора в словарь
        {
            Names.Add(str, k);
        }
        public void SetObj(Device tmp_obj) //Добавление нового прибора в список приборов
        {
            JB_Objects.Add(tmp_obj);
        }
        public void SetObj(Device tmp_obj, int index) //"Обновление" данных прибора(возвращается дополненным на то место, откуда взяли с соблюдением индексов)
        {
            JB_Objects[index] = tmp_obj;
        }
        public int ReturnIndexOfDevice(string str) //Возвращаем индекс прибора по названию
        {
            int result = 0;
            foreach(var valuePair in Names)
            {
                if(valuePair.Key == str)
                {
                    result = valuePair.Value;
                }
            }
            return result;
        }
        public Device ReturnObj(int index) //Возвращаем сам прибор по индексу
        {
            return JB_Objects[index];
        }
        public Device ReturnObj(string str) //Возвращаем прибор по названию
        {
            int result = 0;
            foreach (var valuePair in Names)
            {
                if (valuePair.Key == str)
                {
                    result = valuePair.Value;
                }
            }
            return JB_Objects[result];
        }
        public string GetNameFromDictionaryWithIndex(int k)
        {
            string result = "u have bug";
            foreach(var valuePair in Names)
            {
                if(valuePair.Value == k)
                {
                    result = valuePair.Key;
                }
            }
            return result;
        }
        public List<Device> ReturnList()
        {
            return JB_Objects;
        }
    }
}
