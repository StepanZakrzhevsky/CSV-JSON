﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktika
{
    class Datchik
    {
        private List<List<DateTime>> Data = new List<List<DateTime>>();
        private List<string> uName = new List<string>();
        //private uint Serial;
        private List<List<string>> SensorName = new List<List<string>>();
        private List<List<List<double>>> SensorValues = new List<List<List<double>>>();

        public void AdduName(string name)
        {
            uName.Add(name);
        }

        public void AddSensorName(string name_sensor)
        {
            SensorName[0].Add(name_sensor);
        }

        public void AddValue(double value)
        {
            //SensorValues[1].Add(5);
        }
    }
}
